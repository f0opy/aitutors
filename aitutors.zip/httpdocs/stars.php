<?php 
	require "db.php";

	$star=$_POST['rating'];


	echo $star;


 ?>