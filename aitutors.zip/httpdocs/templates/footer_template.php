<?php  echo '<footer class="footer">
                <div class="footer-container">
                    <div class="footer-logo">
                        <img src="img/logoPngAitututors.png" width="200px">
                    </div>
                        <div class="footer-navigator">
                            <div class="footer-column">
                                
                                <h3 class="footer-column-title">Про</h3>
                                <a href="aboutus"><div class="footer-column-subtitle">Нас</div></a>
                                <a href="aboutteam"><div class="footer-column-subtitle">Команду</div></a>
                            </div>
                            <div class="footer-column">
                                <h3 class="footer-column-title">Контакты</h3>
                                <img class="column-icon" src="img/black_webpict08_1484337066-1.png" width="43px"><div class="footer-column-subtitle wicon">+7 (777) 123 55 74</div>
                                <img class="column-icon" src="img/unnamed%20(2).png" width="47px"><div class="footer-column-subtitle wicon">aitutors2016@gmail.com</div>
                             </div>
                             <div class="footer-column ml50px" >

                                <h3 class="footer-column-title">Ещё</h3>
                                <a href="#"><div class="footer-column-subtitle">Условия</div></a>
                                <a href="#"><div class="footer-column-subtitle">Справочник</div></a>
                            </div>
                        </div> 
                        <hr class="blueline" width="100%" color="#2890B9">
                <div class="iconss">
                    <a href="#"><img src="img/instagram.png"></a>
                    <a href="#"><img src="img/telegram.png"></a>
                    <a href="#"><img src="img/whatsapp.png"></a>
                    <a href="#"><img src="img/twitter.png"></a>
                    <a href="#"><img src="img/facebook%20(1).png"></a>
                </div>
                </div>
               
                    
                    
        	</footer>';?>

