<?php 
session_start();
$mysql=new mysqli('srv-pleskdb49.ps.kz:3306','aitutors_aitu','Astana2020*','aitutors_aitu');
 ?>